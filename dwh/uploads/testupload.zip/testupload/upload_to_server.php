<?php 
    $chunkIndex = isset($_POST["chunkIndex"]) ? $_POST["chunkIndex"] : "";;
    $fileName = "";//Misc.generateHash(15);
    $uploadId = $_POST["uploadId"];
    $complete = $_POST["complete"];
    if($complete == "false")
    {
        
        $attachment = $_FILES["uploadchunkdata"];
        $name = $attachment["name"];
       
        $fileName = $chunkIndex.".".$uploadId;
        move_uploaded_file($attachment["tmp_name"], "tmp/".$fileName);
        echo "hi";
    }
    else{
        echo "hello";
        $fileExtension = $_POST["fileExtension"];
        $title = $_POST["title"];
        $createdBy = $_POST["userId"];
        $fileName = "uploads/".uniqid()."_".$uploadId.".".$fileExtension;
        echo $fileName;
        //merge the files together
            /*parts = [];
            var allFiles = [];
            fs.readdir(constants.tmpPath, function(err, files){
                files = files.map(function (fileName) {
                  return {
                    name: fileName,
                    time: fs.statSync(constants.tmpPath + '/' + fileName).mtime.getTime()
                  };
                })
                .sort(function (a, b) {
                  return a.time - b.time; })
                
                .map(function (v) {
                  return v.name; });

                  files.filter(function(element){
                        var extName = path.extname(element);
                        return extName === '.'+uploadId; 
        
                  }).forEach(function(value) {
                      allFiles.push(value);
                      const data = fs.readFileSync(constants.tmpPath+value);
                      parts.push(data);
                  });
                       
                        fs.writeFile(constants.uploadPath+fileName, Buffer.concat(parts), function(err){
                            const mimeType = mime.lookup(constants.uploadPath+fileName); 
                            console.log(mimeType);
                            var processed = 0;
                            var type = "video";
                            if(mimeType.indexOf("audio") > -1)
                            {
                                processed = 1;
                                type = "audio";
                            }
                            else if(mimeType.indexOf("mp4") > -1 || mimeType.indexOf("webm") > -1 ){
                                processed = 1;
                            }
                
                            const userObj = new User();
                            userObj.saveMedia(title, fileName, 10, type, processed, createdBy).then(function(response){
                               
                                res.send("1");
                            }).catch(function(err){
                                console.log("error", err);
                                res.send("0");
                            })
                            for(const file of allFiles){
                                fs.unlink(constants.tmpPath+file, function(){
                
                                });
                            }
                            deleteOldTmpFiles();
                
                        });
                        // Invoke the next step here however you like
                    
                  });*/

                  $files = glob('tmp/*.'.$uploadId);
                    usort($files, function($a, $b) {
                        return filemtime($a) > filemtime($b);
                    });

                    mergeFiles2($files, $fileName);
                    deleteTmpFiles($files);
        }


function mergeFiles($arrayOfFiles, $outputPath) {

    $dest = fopen($outputPath,"a");

    foreach ($arrayOfFiles as $f) {

        $FH = fopen($f,"r");

        $line = fgets($FH);

        while ($line !== false) {

            fputs($dest,$line);

            $line = fgets($FH);

        }

        fclose($FH);

    }

    fclose($dest);

}

function mergeFiles2($arrayOfFiles, $outputPath)
{
    // and THAT's what you were asking for
// when this triggers - that means your chunks are uploaded
    //if ($chunksUploaded === $num_chunks) {

        /* here you can reassemble chunks together */
    foreach ($arrayOfFiles as $singleFile) {

        $file = fopen($singleFile, 'rb');
        $buff = fread($file, 2097152);
        fclose($file);

        $final = fopen($outputPath, 'ab');
        $write = fwrite($final, $buff);
        fclose($final);

        unlink($arrayOfFiles);
    }
    //}
}
function deleteTmpFiles($arrayOfFiles)
{
    foreach ($arrayOfFiles as $f) {
        echo $f;
        unlink($f);
    }
}



?>