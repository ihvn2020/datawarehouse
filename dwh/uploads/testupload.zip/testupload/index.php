<?php 
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<html>
    <head>
        <title>Test UPload</title>
        <link href="bootstrap.min.css" rel="stylesheet"/>
    </head>
 
<style type="text/css">
	label
	{
		display:block !important;
	}
</style>
<!-- Style of VideoJS -->
<body>
 <!-- Main content -->
                <section class="content">

                    <div class='row'>
                        <div class='col-md-12'>
                            <div class='box box-info'>
                                <div class='box-header'>
                                    <h3 class='box-title'>Add Resource <small></small></h3>
                                    <!-- tools box -->
                                    
                                </div><!-- /.box-header -->
                                <div class='box-body pad'>
                                    <form action="" method="POST">
                                        <div class="row">
                                            <div class="col-md-3 col-sm-6">
                                                Resource Title
                                            </div>
                                            <div class="col-sm-6 col-md-6">
                                                <input type="text" name="title" id="title" class="form-control" />
                                            </div>
                                        </div>
                                        <br/>
                                        
                                        <br/>
                                        <div class="row">
                                           
                                            <div class="col-sm-12">
                                            <div class="row" id="mediaFileDiv">
                                                <div class="col-md-3 col-sm-6">Select File</div>
                                                <div class="col-md-6 col-sm-6">
                                                    <input type="file" name="mediaFile" id="mediaFile" class="form-control" />
                                                </div>
                                            </div>
                                                 <video id="myVideo" class="video-js vjs-default-skin hidden"></video>
                                                 <audio id="myAudio" class="video-js vjs-default-skin hidden"></audio>
        
                                            </div>
                                        </div>
                                        <br/>
                                        <div class="row">
                                            <div class="col-sm-11">
                                                <div class="progress">
                                                    <div class="progress-bar" id="progressBar" role="progressbar" style="width:0%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                                    <span id="progressPercent">0%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <br/>
                                        
                                        <div class="alert alert-success alert-dismissable hidden" id="successMessage">
                                        <i class="fa fa-check"></i>
                                            Media has been successfully uploaded. You can record another media or you can proceed to 
                                            There you can create a new note and attach the created media to it.
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                 <a href="javascript:void(0);" id="uploadResource" class="btn btn-primary" disabled="disabled" >Upload Resource</a>
                                            </div>
                                        </div>




                                    </form>
                                   
								   	
                                   <div class="clearfix"></div>
                                </div>
                            </div><!-- /.box -->

                            
                        </div><!-- /.col-->
                    </div><!-- ./row -->



                </section><!-- /.content -->



<!-- Load VideoJS Record Extension -->
  <script type="text/javascript" src="jquery.min.js"></script>
  <script type="text/javascript" src="bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.form/4.2.2/jquery.form.min.js" type="text/javascript"></script> 
<script type="text/javascript">

function setProgressBar(value)
{
    $("#progressBar").css("width", value+"%");
    $("#progressPercent").html(value+"%");
}

var counter = 1;



var audioData;

var videoBlob ;
var userId = 1;
 var title = "";
 var data = null;
 var type = "";
 var offset = 0;
 var chunk_size = 2*1024*1024; // 2Mbyte Chunk 
 var retry  = 0;
 var uploadId = new Date()+userId;
 var file_extension = "";

 	$(document).ready(function(e) {
       


        $("#uploadResource").click(function(e){
          
            title = $("#title").val();
            type = "custom";
            if(title == "")
            {
                alert("Fill out media title");
            }
            else{
                
                //data = $('#mediaFile')[0].files[0];
                data = document.getElementById("mediaFile").files[0];
                type = "custom";
                //uploadFile();
                
                
                uploadId = new Date().getTime()+"_"+userId;//reset the upload id
                //uploadToServer(title, type, data);
                $("#uploadResource").attr("disabled", "disabled");
                uploadForm(e)

            }
            
        });


        $("#mediaFile").change(function(e) {
            var allowedExt = allowedExtensions["zippedFile"]//use it to get the allowed extensions from the object
            if(!validate_fileupload($("#mediaFile").val(), allowedExt))
            {
                alert("File is not a valid zipped file. Please upload a zipped");
            }
            else{
                $("#uploadResource").removeAttr("disabled");
            }
        });
    });
          
    var allowedExtensions = {"zippedFile":["zip" ] };
                        
    function validate_fileupload(fileName, allowedTypes)
	{
		//var allowed_extensions = new Array("jpg","png","gif");
		var allowed_extensions = allowedTypes
		file_extension = fileName.split('.').pop(); // split function will split the filename by dot(.), and pop function will pop the last element from the array which will give you the extension as well. If there will be no extension then it will return the filename.

		for(var i = 0; i <= allowed_extensions.length; i++)
		{
			if(allowed_extensions[i]==file_extension)
			{
				return true; // valid file extension
			}
		}

		return false;
    }
    




    //function uploadChunk(evt)
    function uploadChunk(chunkedfile)
    {
        
        
         var form = document.getElementById("upload_form");
         var formData = new FormData();
         formData.append('title', title);
        formData.append('type', type);
        formData.append("userId", userId);
        //formData.append('', title);
        console.log(chunkedfile);
        //var baseIp = $("#baseIp").val();
        //var basePort = $("#basePort").val();
        formData.append("chunking", 'true');
         formData.append("uploadfilename",  title);
         formData.append("uploadId",  uploadId );
         formData.append("fileExtension", file_extension);
         if(chunkedfile == null)
         {
            formData.append("complete",  "true" );
            offset = 0;
         }
         else{
            var upload_size = chunkedfile.size;
            formData.append("complete",  "false" );
            formData.append("offset",  offset );
            formData.append("chunkIndex",  offset);
            formData.append("totalChunksCount",  data.size / chunk_size);
            formData.append("uploadchunkdata",  chunkedfile);
         }
        
         $.ajax({
                type: 'post',
                  data: formData,    
                  processData: false, 
                  contentType: false,
                  url:"upload_to_server.php",
                success: function(success){
                    if(chunkedfile == null)
                    {
                        $("#successMessage").removeClass("hidden");
                    }else{
                        offset += chunkedfile.size;
                    readSlice(null);
                    }
                    retry = 1;
                    
                },
                error: function(error, xhr, status){
                    console.log(error)
                    console.log(xhr)
                    console.log(status)
                    if( ++retry >= 20 ) {
                            setProgressBar("Upload failed")
                    }
                    else {
                        
                        console.log(error)
                        readSlice(null);//try to upload
                        console.log("retry")
                            //retry = 0;
                            //uploadChunk(evt);
                    }
                }
            });
    }

   function readCallback(evt) 
   {
        if (evt.target.error == null) {
                uploadChunk(evt);
        } else {
            setProgressBar("File read error on disk: " + evt.target.error);
            return;
        }
    }
    
    function readSlice(e)
    {
        //var files = document.getElementById("file_input");
        var file = data;//files.files[0];
        
          var reader = new FileReader();
          if( offset < file.size )
          {
            setProgressBar((100*offset/file.size).toFixed(0)  );
            var blob = file.slice( offset, offset + chunk_size );
            uploadChunk(blob);
           //reader.onload = readCallback;
           //reader.readAsDataURL(blob);

           
        }
        else
        {
            uploadChunk(null)
            setProgressBar(100);
            //progress_label.html("Upload complete"); 
        }
    } 

    function uploadForm(e){
        e.preventDefault();
        offset = 0; 
        readSlice(e);
        //progress_label.html("Starting...");
             
    }    
    
</script>
</body>
</html>